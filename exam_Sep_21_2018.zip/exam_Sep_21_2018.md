
Before you turn this problem in, make sure everything runs as expected. First, **restart the kernel** (in the menubar, select Kernel$\rightarrow$Restart) and then **run all cells** (in the menubar, select Cell$\rightarrow$Run All).

Make sure you fill in any place that says `YOUR CODE HERE` or "YOUR ANSWER HERE", as well as your name and collaborators below:


```python
NAME = "Piet Steeghs, 2002534"
COLLABORATORS = ""
```

---

Fill in the cell above to provide us with your name and student number, like

NAME = "Adam Smith, #student number#"

where you replace "#student number#" with your ... (very good!)

Unfortunately, you are not allowed to work with "COLLABORATORS" in this exam.

# exam September 21st, 2018

With this python part of the exam you can earn at max. 4 points.




In the first cell of the notebook, give us your name and student number in the way indicated above. 

Fill in the notebook (see below for code cells and text cells that you need to fill in).

If you look at the menus above (File, Edit, View etc.), there is one called "Cell". If you click on this, you can change the "Cell Type". Choose "Code" when you are typing python or R code. Choose "Markdown" when you are typing, well, markdown.

When you finish the notebook, make sure that you **save it with the output of your code included**. 

Then put it on github, e.g. by dragging it onto github (see instructions below). 

Finally, add a link to your README file with the name of this exam: "Exam September 21, 2018".



## Generating and plotting data

We start by importing the usual libraries.


```python
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from scipy import optimize
%matplotlib inline
```

#### a) [0.5 point] Explain in words what the following code does. 


```python
n_observations = 100
x = np.random.uniform(0,2,size=n_observations)
df = pd.DataFrame({'x': x})
```


```python
df
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>x</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.570293</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.327070</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.017152</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.692022</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.440380</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.696562</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1.757088</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.288679</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1.024700</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1.778159</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.086992</td>
    </tr>
    <tr>
      <th>11</th>
      <td>1.873543</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.567306</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.441739</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1.789548</td>
    </tr>
    <tr>
      <th>15</th>
      <td>1.041128</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.679438</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.926108</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1.813647</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1.642879</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.114901</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0.926917</td>
    </tr>
    <tr>
      <th>22</th>
      <td>1.356456</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0.180575</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.669523</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.451256</td>
    </tr>
    <tr>
      <th>26</th>
      <td>1.838641</td>
    </tr>
    <tr>
      <th>27</th>
      <td>1.543313</td>
    </tr>
    <tr>
      <th>28</th>
      <td>1.085247</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0.646328</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>0.321475</td>
    </tr>
    <tr>
      <th>71</th>
      <td>1.533355</td>
    </tr>
    <tr>
      <th>72</th>
      <td>0.110786</td>
    </tr>
    <tr>
      <th>73</th>
      <td>1.820063</td>
    </tr>
    <tr>
      <th>74</th>
      <td>1.589361</td>
    </tr>
    <tr>
      <th>75</th>
      <td>1.665239</td>
    </tr>
    <tr>
      <th>76</th>
      <td>1.102500</td>
    </tr>
    <tr>
      <th>77</th>
      <td>1.764562</td>
    </tr>
    <tr>
      <th>78</th>
      <td>0.652836</td>
    </tr>
    <tr>
      <th>79</th>
      <td>1.552225</td>
    </tr>
    <tr>
      <th>80</th>
      <td>0.092957</td>
    </tr>
    <tr>
      <th>81</th>
      <td>1.619693</td>
    </tr>
    <tr>
      <th>82</th>
      <td>0.627983</td>
    </tr>
    <tr>
      <th>83</th>
      <td>0.884964</td>
    </tr>
    <tr>
      <th>84</th>
      <td>0.777704</td>
    </tr>
    <tr>
      <th>85</th>
      <td>0.738016</td>
    </tr>
    <tr>
      <th>86</th>
      <td>0.004766</td>
    </tr>
    <tr>
      <th>87</th>
      <td>1.156953</td>
    </tr>
    <tr>
      <th>88</th>
      <td>0.388443</td>
    </tr>
    <tr>
      <th>89</th>
      <td>0.076877</td>
    </tr>
    <tr>
      <th>90</th>
      <td>0.799024</td>
    </tr>
    <tr>
      <th>91</th>
      <td>1.991933</td>
    </tr>
    <tr>
      <th>92</th>
      <td>0.126880</td>
    </tr>
    <tr>
      <th>93</th>
      <td>0.930354</td>
    </tr>
    <tr>
      <th>94</th>
      <td>0.080755</td>
    </tr>
    <tr>
      <th>95</th>
      <td>1.548812</td>
    </tr>
    <tr>
      <th>96</th>
      <td>0.890521</td>
    </tr>
    <tr>
      <th>97</th>
      <td>1.921127</td>
    </tr>
    <tr>
      <th>98</th>
      <td>0.892350</td>
    </tr>
    <tr>
      <th>99</th>
      <td>0.308356</td>
    </tr>
  </tbody>
</table>
<p>100 rows × 1 columns</p>
</div>



The code creates a dataframe, where the amount of rows is equal to the amount of observations (100). The values of the observations are named under 'x'.

Now we are going to add some columns to the dataframe `df`.

#### b) [0.5 points] Add two columns to the data frame: (i) column `y` where $y=3*x+5$ and (ii) column `z` where $z = (x-1)^2$.


```python
y = 3*x+5
z = (x-1)**2
df['i'] = y
df['ii']= z
df
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>x</th>
      <th>i</th>
      <th>ii</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.570293</td>
      <td>6.710880</td>
      <td>0.184648</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.327070</td>
      <td>5.981210</td>
      <td>0.452835</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.017152</td>
      <td>5.051455</td>
      <td>0.965991</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.692022</td>
      <td>10.076066</td>
      <td>0.478894</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.440380</td>
      <td>9.321139</td>
      <td>0.193934</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.696562</td>
      <td>10.089686</td>
      <td>0.485198</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1.757088</td>
      <td>10.271265</td>
      <td>0.573183</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.288679</td>
      <td>5.866037</td>
      <td>0.505977</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1.024700</td>
      <td>8.074101</td>
      <td>0.000610</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1.778159</td>
      <td>10.334476</td>
      <td>0.605531</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.086992</td>
      <td>5.260977</td>
      <td>0.833583</td>
    </tr>
    <tr>
      <th>11</th>
      <td>1.873543</td>
      <td>10.620630</td>
      <td>0.763078</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.567306</td>
      <td>6.701918</td>
      <td>0.187224</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.441739</td>
      <td>6.325218</td>
      <td>0.311655</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1.789548</td>
      <td>10.368645</td>
      <td>0.623386</td>
    </tr>
    <tr>
      <th>15</th>
      <td>1.041128</td>
      <td>8.123384</td>
      <td>0.001692</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.679438</td>
      <td>7.038314</td>
      <td>0.102760</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.926108</td>
      <td>7.778323</td>
      <td>0.005460</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1.813647</td>
      <td>10.440941</td>
      <td>0.662022</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1.642879</td>
      <td>9.928637</td>
      <td>0.413294</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.114901</td>
      <td>5.344703</td>
      <td>0.783400</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0.926917</td>
      <td>7.780752</td>
      <td>0.005341</td>
    </tr>
    <tr>
      <th>22</th>
      <td>1.356456</td>
      <td>9.069367</td>
      <td>0.127061</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0.180575</td>
      <td>5.541726</td>
      <td>0.671457</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.669523</td>
      <td>7.008568</td>
      <td>0.109215</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.451256</td>
      <td>6.353768</td>
      <td>0.301120</td>
    </tr>
    <tr>
      <th>26</th>
      <td>1.838641</td>
      <td>10.515923</td>
      <td>0.703319</td>
    </tr>
    <tr>
      <th>27</th>
      <td>1.543313</td>
      <td>9.629940</td>
      <td>0.295189</td>
    </tr>
    <tr>
      <th>28</th>
      <td>1.085247</td>
      <td>8.255742</td>
      <td>0.007267</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0.646328</td>
      <td>6.938984</td>
      <td>0.125084</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>0.321475</td>
      <td>5.964424</td>
      <td>0.460397</td>
    </tr>
    <tr>
      <th>71</th>
      <td>1.533355</td>
      <td>9.600064</td>
      <td>0.284467</td>
    </tr>
    <tr>
      <th>72</th>
      <td>0.110786</td>
      <td>5.332358</td>
      <td>0.790701</td>
    </tr>
    <tr>
      <th>73</th>
      <td>1.820063</td>
      <td>10.460190</td>
      <td>0.672504</td>
    </tr>
    <tr>
      <th>74</th>
      <td>1.589361</td>
      <td>9.768083</td>
      <td>0.347346</td>
    </tr>
    <tr>
      <th>75</th>
      <td>1.665239</td>
      <td>9.995718</td>
      <td>0.442543</td>
    </tr>
    <tr>
      <th>76</th>
      <td>1.102500</td>
      <td>8.307499</td>
      <td>0.010506</td>
    </tr>
    <tr>
      <th>77</th>
      <td>1.764562</td>
      <td>10.293687</td>
      <td>0.584556</td>
    </tr>
    <tr>
      <th>78</th>
      <td>0.652836</td>
      <td>6.958507</td>
      <td>0.120523</td>
    </tr>
    <tr>
      <th>79</th>
      <td>1.552225</td>
      <td>9.656676</td>
      <td>0.304953</td>
    </tr>
    <tr>
      <th>80</th>
      <td>0.092957</td>
      <td>5.278871</td>
      <td>0.822727</td>
    </tr>
    <tr>
      <th>81</th>
      <td>1.619693</td>
      <td>9.859080</td>
      <td>0.384020</td>
    </tr>
    <tr>
      <th>82</th>
      <td>0.627983</td>
      <td>6.883949</td>
      <td>0.138397</td>
    </tr>
    <tr>
      <th>83</th>
      <td>0.884964</td>
      <td>7.654892</td>
      <td>0.013233</td>
    </tr>
    <tr>
      <th>84</th>
      <td>0.777704</td>
      <td>7.333113</td>
      <td>0.049415</td>
    </tr>
    <tr>
      <th>85</th>
      <td>0.738016</td>
      <td>7.214047</td>
      <td>0.068636</td>
    </tr>
    <tr>
      <th>86</th>
      <td>0.004766</td>
      <td>5.014297</td>
      <td>0.990491</td>
    </tr>
    <tr>
      <th>87</th>
      <td>1.156953</td>
      <td>8.470860</td>
      <td>0.024634</td>
    </tr>
    <tr>
      <th>88</th>
      <td>0.388443</td>
      <td>6.165329</td>
      <td>0.374002</td>
    </tr>
    <tr>
      <th>89</th>
      <td>0.076877</td>
      <td>5.230630</td>
      <td>0.852157</td>
    </tr>
    <tr>
      <th>90</th>
      <td>0.799024</td>
      <td>7.397072</td>
      <td>0.040391</td>
    </tr>
    <tr>
      <th>91</th>
      <td>1.991933</td>
      <td>10.975798</td>
      <td>0.983930</td>
    </tr>
    <tr>
      <th>92</th>
      <td>0.126880</td>
      <td>5.380640</td>
      <td>0.762338</td>
    </tr>
    <tr>
      <th>93</th>
      <td>0.930354</td>
      <td>7.791062</td>
      <td>0.004851</td>
    </tr>
    <tr>
      <th>94</th>
      <td>0.080755</td>
      <td>5.242266</td>
      <td>0.845011</td>
    </tr>
    <tr>
      <th>95</th>
      <td>1.548812</td>
      <td>9.646435</td>
      <td>0.301194</td>
    </tr>
    <tr>
      <th>96</th>
      <td>0.890521</td>
      <td>7.671563</td>
      <td>0.011986</td>
    </tr>
    <tr>
      <th>97</th>
      <td>1.921127</td>
      <td>10.763382</td>
      <td>0.848476</td>
    </tr>
    <tr>
      <th>98</th>
      <td>0.892350</td>
      <td>7.677051</td>
      <td>0.011588</td>
    </tr>
    <tr>
      <th>99</th>
      <td>0.308356</td>
      <td>5.925067</td>
      <td>0.478372</td>
    </tr>
  </tbody>
</table>
<p>100 rows × 3 columns</p>
</div>



I added the columns 'i' and 'ii' to the dataframe. the column 'i' containing the formula 3*x+5. and the column 'ii' containing the forumula (x-1)^2.

#### c) [0.5 point] Calculate the means and standard deviations for `x` and `y`. 

[hint: you can do this with one command or with four separate commands]


```python
np.mean(x) 
```




    1.0202783343053721




```python
np.std(x)
```




    0.62316226855006385




```python
np.mean(y)
```




    8.0608350029161144




```python
np.std(y)
```




    1.8694868056501912



I added codes so that means and standard deviations of x and y would be calculated

#### d) [0.5 points] Use your knowledge of statistics to explain the relations (i) between the means of `x` and `y` and (ii) between the standard deviations of `x` and `y`.

Relation between the means: y is always 5 bigger than x (due to the last bit of the formula of y, (+5)). And for every increasing value of x. y increases with 3 times that value (due to the first bit of the formula of y, (3*x))

Relation between the standard deviations: The greater the difference between the value of x and the mean of x, the greater the standard deviation of y, again, due to the formula of y

#### e) [1 point] Plot a histogram of `x` with fractions (not absolute numbers) on the vertical axis. Add the label $x$ to the horizontal axis.


```python
plt.hist(df['x'])
plt.xlabel('x')
plt.ylabel('')
plt.show()
```


![png](output_26_0.png)


I plotted a histogram of x with the value of x on the horizontal axis, using the data of x.

#### f) [0.5 points] Make a scatter plot of `y` vs `z` with the label $y$ on the horizontal axis and the label $z$ on the vertical axis.


```python
plt.scatter(y,z)
plt.xlabel('y')
plt.ylabel('z')
plt.title('f')
plt.legend
plt.show
```




    <function matplotlib.pyplot.show>




![png](output_29_1.png)


Here i created a scatter plot of y and z. Showing the relation between y and z.

This relation looks rather "perfect". We want to make a "noisy" version of this graph.

#### g) [0.5 points] Create a variable `z2` equal to `z` but with some "noise" added to it. That is, add a random variable (vector) with mean 0 to `z` to get `z2`. Then plot `y` against `z2`. Adjust the standard deviation of the "noise" variable such that the shape of the figure under f) can still be recognized but not perfectly.

[hint: under a) you have seen the library that contains functions to create a "noisy variable"]

## Github

After you have finished, we need to upload this notebook on github.

Instructions on how to upload this on github can be found [on this page](http://janboone.github.io/programming-for-economists/github.html). This page has two screencasts: one shows how to drag the notebook onto your github page, the other shows how you can use the command line to upload your notebook.


Remember to update the README file in your repository to include a link to this notebook on github.


The links that you should post start with “github.com/” and are NOT of the form “http://localhost”. Make sure you test your links after uploading.
